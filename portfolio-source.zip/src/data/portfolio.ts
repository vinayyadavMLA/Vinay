import {
  SiPython, SiOpenjdk, SiJavascript, SiMysql,
  SiTensorflow, SiKeras, SiScikitlearn, SiNumpy, SiPandas, SiOpencv,
  SiJupyter, SiGooglecolab, SiGit, SiGithub,
} from "react-icons/si";
import { FaBrain, FaProjectDiagram, FaDatabase, FaCode, FaChartBar, FaServer } from "react-icons/fa";

export const profile = {
  name: "Minchala Vinay Kumar",
  title: "AI/ML Engineer",
  typing: [
    "AI/ML Engineer",
    "Deep Learning Practitioner",
    "Data Scientist",
    "Computer Vision Enthusiast",
  ],
  intro:
    "Passionate AI/ML Engineer and B.Tech graduate in Artificial Intelligence and Data Science. I design, train, and evaluate deep learning and ML models — from CNN-based image classifiers to NLP pipelines and unsupervised pattern mining.",
  email: "minchalavinay579@gmail.com",
  phone: "+91 83745 77884",
  github: "https://github.com/minchalavinay",
  linkedin: "https://linkedin.com/in/minchalavinaykumar",
  resume: "/resume.pdf",
  location: "Chitvel, Andhra Pradesh, India",
};

export const about = {
  summary:
    "Passionate AI/ML Engineer with hands-on experience designing, training, and evaluating deep learning and machine learning models. Proficient in building CNN-based image classification systems, NLP text classification pipelines (Naive Bayes), and unsupervised pattern recognition (Association Rule Mining). Skilled in Python, TensorFlow/Keras, Scikit-learn, feature engineering, model optimization, and end-to-end ML lifecycle management.",
  objective:
    "Seeking an AI Engineer, Machine Learning Engineer, or Data Scientist role where I can build intelligent, production-grade solutions at scale and continue growing alongside a world-class engineering team.",
  strengths: [
    { title: "Deep Learning", desc: "CNNs, TensorFlow/Keras, model tuning, overfitting control." },
    { title: "NLP Pipelines", desc: "Tokenization, TF-IDF, Naive Bayes — end-to-end text ML." },
    { title: "Computer Vision", desc: "OpenCV + Keras for real-time inference on live video." },
    { title: "Model Deployment", desc: "Serializing models and serving them through REST APIs." },
  ],
};

export const skills = [
  {
    category: "Programming",
    items: [
      { name: "Python (Advanced)", level: 95, Icon: SiPython },
      { name: "Core Java", level: 78, Icon: SiOpenjdk },
      { name: "SQL", level: 85, Icon: SiMysql },
      { name: "JavaScript", level: 70, Icon: SiJavascript },
    ],
  },
  {
    category: "Machine Learning & AI",
    items: [
      { name: "Supervised Learning (CNN, Naive Bayes)", level: 92, Icon: FaBrain },
      { name: "Unsupervised Learning (Apriori, Clustering)", level: 85, Icon: FaProjectDiagram },
      { name: "Hyperparameter Tuning", level: 88, Icon: FaChartBar },
      { name: "Cross-Validation & Regularization", level: 86, Icon: FaCode },
    ],
  },
  {
    category: "Deep Learning",
    items: [
      { name: "TensorFlow 2.x", level: 90, Icon: SiTensorflow },
      { name: "Keras (Sequential & Functional API)", level: 90, Icon: SiKeras },
      { name: "Convolutional Neural Networks", level: 92, Icon: FaBrain },
      { name: "ImageDataGenerator & Augmentation", level: 85, Icon: FaProjectDiagram },
    ],
  },
  {
    category: "NLP & Data Science",
    items: [
      { name: "NLTK, TF-IDF, Bag of Words", level: 88, Icon: FaBrain },
      { name: "Pandas", level: 92, Icon: SiPandas },
      { name: "NumPy", level: 92, Icon: SiNumpy },
      { name: "Scikit-learn", level: 90, Icon: SiScikitlearn },
      { name: "OpenCV", level: 85, Icon: SiOpencv },
    ],
  },
  {
    category: "MLOps & Tools",
    items: [
      { name: "Jupyter Notebook", level: 92, Icon: SiJupyter },
      { name: "Google Colab", level: 90, Icon: SiGooglecolab },
      { name: "Git & GitHub", level: 85, Icon: SiGithub },
      { name: "Model Serialization (joblib/pickle)", level: 85, Icon: FaCode },
      { name: "Git", level: 88, Icon: SiGit },
    ],
  },
  {
    category: "Databases",
    items: [
      { name: "MySQL", level: 85, Icon: SiMysql },
      { name: "Data Pipelines & ETL", level: 80, Icon: FaServer },
      { name: "Feature Store Concepts", level: 75, Icon: FaDatabase },
    ],
  },
];

export const projects = [
  {
    title: "Sign Language Detection (CNN)",
    desc: "Multi-class CNN image classifier in TensorFlow/Keras with data augmentation on 10,000+ gesture images. Achieved 94% test accuracy with a real-time OpenCV webcam inference module.",
    image: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&q=80",
    tech: ["Python", "TensorFlow", "Keras", "OpenCV", "CNN"],
    demo: "#",
    github: "https://github.com/minchalavinay",
  },
  {
    title: "Email Spam Detection — NLP Pipeline",
    desc: "End-to-end NLP pipeline: cleaning → tokenization → stop-word removal → stemming → TF-IDF → Naive Bayes. Achieved 96%+ accuracy with k-fold cross-validation and ROC-AUC evaluation.",
    image: "https://images.unsplash.com/photo-1596526131083-e8c633c948d2?w=800&q=80",
    tech: ["Python", "Scikit-learn", "NLTK", "NLP", "Pandas"],
    demo: "#",
    github: "https://github.com/minchalavinay",
  },
  {
    title: "Market Basket Analysis — Apriori",
    desc: "Unsupervised pattern mining on retail transactions using the Apriori algorithm. Filtered association rules by support, confidence, and lift; visualized association networks for stakeholders.",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&q=80",
    tech: ["Python", "mlxtend", "Pandas", "MySQL", "Seaborn"],
    demo: "#",
    github: "https://github.com/minchalavinay",
  },
];

export const experience = [
  {
    role: "AI & Full Stack Developer Intern",
    company: "Palle Technologies",
    period: "2023",
    points: [
      "Developed AI-integrated web applications combining Python ML models with a Java Spring Boot REST API back-end and MySQL database.",
      "Implemented data preprocessing and feature engineering scripts in Python for model training datasets.",
      "Contributed to the model deployment pipeline by serializing trained models and exposing inference endpoints via REST APIs.",
      "Collaborated in an agile team to deliver AI-powered application features, applying software engineering best practices.",
    ],
  },
];

export const education = [
  {
    degree: "B.Tech — Artificial Intelligence & Data Science",
    school: "Arjun College of Technology, Anna University, Coimbatore",
    period: "Graduated June 2024",
    score: "CGPA: 7.92 / 10.0",
  },
];

export const certifications = [
  "Relevant Coursework: Machine Learning, Deep Learning",
  "Natural Language Processing & Computer Vision",
  "Data Mining, Statistics & Probability",
  "Neural Networks & Python for AI",
];

export const achievements = [
  { title: "94% Accuracy — Sign Language CNN", desc: "Reduced overfitting via dropout, BatchNorm, and tuned hyperparameters across 10,000+ images." },
  { title: "96%+ Accuracy — Spam Classifier", desc: "Robust Naive Bayes pipeline validated with k-fold CV and ROC-AUC analysis." },
  { title: "Real-Time CV Inference", desc: "Built a live webcam gesture recognition module using OpenCV + Keras." },
  { title: "End-to-End ML Deployment", desc: "Shipped serialized models behind REST API endpoints during internship." },
  { title: "Team Leadership", desc: "Recognised competency in collaborative, agile AI product delivery." },
  { title: "Research & Innovation", desc: "Strong focus on applied research across CV, NLP, and unsupervised learning." },
];

export const codingStats = [
  { platform: "Projects Shipped", value: "3+", sub: "CV · NLP · Unsupervised ML" },
  { platform: "Best Model Accuracy", value: "96%+", sub: "Email spam classifier" },
  { platform: "CGPA", value: "7.92", sub: "B.Tech AI & Data Science" },
  { platform: "Languages", value: "3", sub: "English · Telugu · Hindi" },
];

export const testimonials = [
  {
    quote:
      "Vinay consistently shipped AI-powered features that delighted our team. He pairs strong Python skills with a real product mindset.",
    name: "Engineering Mentor",
    role: "Palle Technologies",
  },
  {
    quote:
      "An incredibly fast learner. He picked up TensorFlow and Keras and within weeks was tuning CNN architectures that beat our baseline.",
    name: "Faculty Advisor",
    role: "Arjun College of Technology",
  },
  {
    quote:
      "Vinay's NLP pipeline work was meticulous — clean code, solid evaluation metrics, and thoughtful experimentation.",
    name: "Project Reviewer",
    role: "Capstone Panel",
  },
];
