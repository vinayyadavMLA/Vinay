import { motion } from "framer-motion";
import { Trophy } from "lucide-react";
import { Section } from "./Section";
import { achievements, codingStats } from "@/data/portfolio";

export function Achievements() {
  return (
    <Section id="achievements" kicker="Wins" title="Achievements">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        {codingStats.map((s, i) => (
          <motion.div
            key={s.platform}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.08 }}
            className="glass rounded-2xl p-5 text-center"
          >
            <div className="text-xs text-muted-foreground">{s.platform}</div>
            <div className="text-3xl font-bold gradient-text mt-1">{s.value}</div>
            <div className="text-xs text-muted-foreground mt-1">{s.sub}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {achievements.map((a, i) => (
          <motion.div
            key={a.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.06 }}
            whileHover={{ y: -4 }}
            className="glass rounded-2xl p-6 group"
          >
            <Trophy className="size-6 text-primary mb-3 group-hover:scale-110 transition-transform" />
            <h3 className="font-semibold text-sm">{a.title}</h3>
            <p className="text-sm text-muted-foreground mt-1">{a.desc}</p>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}
