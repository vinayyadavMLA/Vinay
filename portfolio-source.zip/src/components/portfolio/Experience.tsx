import { motion } from "framer-motion";
import { Briefcase } from "lucide-react";
import { Section } from "./Section";
import { experience } from "@/data/portfolio";

export function Experience() {
  return (
    <Section id="experience" kicker="Journey" title="Experience">
      <div className="relative max-w-3xl mx-auto">
        <div className="absolute left-4 sm:left-1/2 top-0 bottom-0 w-px gradient-bg opacity-40" />
        {experience.map((e, i) => (
          <motion.div
            key={e.role}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.5, delay: i * 0.1 }}
            className={`relative mb-10 sm:w-1/2 ${
              i % 2 === 0 ? "sm:pr-10" : "sm:ml-auto sm:pl-10"
            } pl-12 sm:pl-10`}
          >
            <div className="absolute left-2 sm:left-auto sm:right-auto sm:top-2 size-5 rounded-full gradient-bg neon-glow flex items-center justify-center"
                 style={{ [i % 2 === 0 ? "right" : "left"]: "-10px" } as React.CSSProperties}>
              <Briefcase className="size-2.5 text-primary-foreground" />
            </div>
            <div className="glass rounded-2xl p-6">
              <div className="text-xs text-muted-foreground">{e.period}</div>
              <h3 className="font-semibold text-lg mt-1">{e.role}</h3>
              <div className="text-sm gradient-text font-medium">{e.company}</div>
              <ul className="mt-3 space-y-1.5 text-sm text-muted-foreground list-disc pl-5">
                {e.points.map((pt) => (
                  <li key={pt}>{pt}</li>
                ))}
              </ul>
            </div>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}
