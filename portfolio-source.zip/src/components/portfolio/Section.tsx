import { motion } from "framer-motion";
import { ReactNode } from "react";

export function Section({
  id, title, kicker, children,
}: { id: string; title: string; kicker?: string; children: ReactNode }) {
  return (
    <section id={id} className="relative py-24 px-4">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          {kicker && (
            <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-2">
              {kicker}
            </div>
          )}
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight">
            <span className="gradient-text">{title}</span>
          </h2>
          <div className="mt-4 mx-auto h-1 w-16 gradient-bg rounded-full" />
        </motion.div>
        {children}
      </div>
    </section>
  );
}
