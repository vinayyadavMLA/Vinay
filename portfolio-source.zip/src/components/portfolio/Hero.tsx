import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { Download, Mail, Github, Linkedin, MapPin } from "lucide-react";
import avatar from "@/assets/avatar.jpg";
import { profile } from "@/data/portfolio";

function Typing({ words }: { words: string[] }) {
  const [idx, setIdx] = useState(0);
  const [text, setText] = useState("");
  const [del, setDel] = useState(false);

  useEffect(() => {
    const word = words[idx % words.length];
    const speed = del ? 40 : 80;
    const t = setTimeout(() => {
      if (!del) {
        const next = word.slice(0, text.length + 1);
        setText(next);
        if (next === word) setTimeout(() => setDel(true), 1400);
      } else {
        const next = word.slice(0, text.length - 1);
        setText(next);
        if (next === "") {
          setDel(false);
          setIdx((i) => i + 1);
        }
      }
    }, speed);
    return () => clearTimeout(t);
  }, [text, del, idx, words]);

  return (
    <span className="gradient-text font-semibold">
      {text}
      <span className="caret h-[1em] align-middle" />
    </span>
  );
}

export function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-28 pb-16 px-4">
      <div className="absolute inset-0 grid-bg opacity-30 -z-10" />
      <div className="mx-auto max-w-6xl grid lg:grid-cols-[1.2fr_1fr] gap-12 items-center w-full">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div className="inline-flex items-center gap-2 glass rounded-full px-3 py-1 text-xs text-muted-foreground mb-6">
            <span className="size-2 rounded-full bg-green-400 animate-pulse" />
            Open to full-time opportunities
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-tight">
            Hi, I'm <span className="gradient-text">{profile.name}</span>
          </h1>
          <h2 className="mt-4 text-xl sm:text-2xl text-muted-foreground">
            I'm a <Typing words={profile.typing} />
          </h2>
          <p className="mt-6 text-base sm:text-lg text-muted-foreground max-w-xl leading-relaxed">
            {profile.intro}
          </p>
          <div className="mt-6 flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="size-4" /> {profile.location}
          </div>

          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href={profile.resume}
              download
              className="gradient-bg text-primary-foreground px-5 py-3 rounded-xl font-medium inline-flex items-center gap-2 hover:scale-105 transition-transform neon-glow"
            >
              <Download className="size-4" /> Download Resume
            </a>
            <a
              href={`mailto:${profile.email}`}
              className="glass px-5 py-3 rounded-xl font-medium inline-flex items-center gap-2 hover:bg-foreground/5 transition-colors"
            >
              <Mail className="size-4" /> Email
            </a>
            <a
              href={profile.linkedin}
              target="_blank"
              rel="noreferrer"
              aria-label="LinkedIn"
              className="glass p-3 rounded-xl hover:bg-foreground/5 transition-colors"
            >
              <Linkedin className="size-5" />
            </a>
            <a
              href={profile.github}
              target="_blank"
              rel="noreferrer"
              aria-label="GitHub"
              className="glass p-3 rounded-xl hover:bg-foreground/5 transition-colors"
            >
              <Github className="size-5" />
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="relative mx-auto"
        >
          <div className="absolute -inset-6 gradient-bg rounded-full blur-3xl opacity-40" />
          <div className="relative float">
            <div className="size-64 sm:size-80 rounded-full p-1 gradient-bg">
              <img
                src={avatar}
                alt={`Portrait of ${profile.name}`}
                className="size-full rounded-full object-cover border-4 border-background"
                loading="eager"
              />
            </div>
            <div className="absolute -bottom-3 -right-3 glass-strong rounded-2xl px-4 py-2 text-sm font-medium">
              👋 Let's build
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
