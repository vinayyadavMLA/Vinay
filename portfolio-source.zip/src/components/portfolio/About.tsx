import { motion } from "framer-motion";
import { Section } from "./Section";
import { about } from "@/data/portfolio";
import { Lightbulb, Target, Rocket, Users } from "lucide-react";

const icons = [Lightbulb, Target, Rocket, Users];

export function About() {
  return (
    <Section id="about" kicker="About me" title="Who I am">
      <div className="grid lg:grid-cols-2 gap-8 items-start">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="glass rounded-2xl p-8"
        >
          <h3 className="text-xl font-semibold mb-3">Professional summary</h3>
          <p className="text-muted-foreground leading-relaxed">{about.summary}</p>
          <h3 className="text-xl font-semibold mt-8 mb-3">Career objective</h3>
          <p className="text-muted-foreground leading-relaxed">{about.objective}</p>
        </motion.div>

        <div className="grid sm:grid-cols-2 gap-4">
          {about.strengths.map((s, i) => {
            const Icon = icons[i % icons.length];
            return (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                whileHover={{ y: -6 }}
                className="glass rounded-2xl p-6 group"
              >
                <div className="size-11 rounded-xl gradient-bg flex items-center justify-center text-primary-foreground mb-4 group-hover:scale-110 transition-transform">
                  <Icon className="size-5" />
                </div>
                <h4 className="font-semibold mb-1">{s.title}</h4>
                <p className="text-sm text-muted-foreground">{s.desc}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </Section>
  );
}
