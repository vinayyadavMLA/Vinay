import { motion } from "framer-motion";
import { GraduationCap, BadgeCheck } from "lucide-react";
import { Section } from "./Section";
import { education, certifications } from "@/data/portfolio";

export function Education() {
  return (
    <Section id="education" kicker="Background" title="Education">
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="space-y-5">
          {education.map((ed, i) => (
            <motion.div
              key={ed.degree}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="glass rounded-2xl p-6 flex gap-4"
            >
              <div className="size-12 rounded-xl gradient-bg flex items-center justify-center text-primary-foreground shrink-0">
                <GraduationCap className="size-6" />
              </div>
              <div>
                <h3 className="font-semibold">{ed.degree}</h3>
                <div className="text-sm gradient-text">{ed.school}</div>
                <div className="text-xs text-muted-foreground mt-1">{ed.period}</div>
                <div className="text-sm mt-2 font-medium">{ed.score}</div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="glass rounded-2xl p-6"
        >
          <h3 className="font-semibold mb-4">Certifications</h3>
          <ul className="space-y-3">
            {certifications.map((c) => (
              <li key={c} className="flex items-start gap-3 text-sm">
                <BadgeCheck className="size-5 text-primary shrink-0 mt-0.5" />
                <span>{c}</span>
              </li>
            ))}
          </ul>
        </motion.div>
      </div>
    </Section>
  );
}
