import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ExternalLink, Github } from "lucide-react";
import { Section } from "./Section";
import { projects } from "@/data/portfolio";

export function Projects() {
  const allTechs = useMemo(() => {
    const set = new Set<string>();
    projects.forEach((p) => p.tech.forEach((t) => set.add(t)));
    return ["All", ...Array.from(set)];
  }, []);
  const [filter, setFilter] = useState("All");

  const filtered = filter === "All" ? projects : projects.filter((p) => p.tech.includes(filter));

  return (
    <Section id="projects" kicker="Selected work" title="Projects">
      <div className="flex flex-wrap gap-2 justify-center mb-10">
        {allTechs.map((t) => (
          <button
            key={t}
            onClick={() => setFilter(t)}
            className={`px-4 py-1.5 rounded-full text-sm transition-all ${
              filter === t
                ? "gradient-bg text-primary-foreground neon-glow"
                : "glass hover:bg-foreground/5"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <motion.div layout className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {filtered.map((p, i) => (
            <motion.article
              key={p.title}
              layout
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              whileHover={{ y: -8 }}
              className="group glass rounded-2xl overflow-hidden flex flex-col"
            >
              <div className="aspect-video overflow-hidden relative">
                <img
                  src={p.image}
                  alt={p.title}
                  loading="lazy"
                  className="size-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <h3 className="text-lg font-semibold mb-2">{p.title}</h3>
                <p className="text-sm text-muted-foreground flex-1">{p.desc}</p>
                <div className="flex flex-wrap gap-1.5 mt-4">
                  {p.tech.map((t) => (
                    <span key={t} className="text-xs px-2 py-1 rounded-md bg-foreground/5 border border-border">
                      {t}
                    </span>
                  ))}
                </div>
                <div className="flex gap-2 mt-5">
                  <a
                    href={p.demo}
                    className="flex-1 gradient-bg text-primary-foreground text-sm py-2 rounded-lg inline-flex items-center justify-center gap-1.5 hover:opacity-90"
                  >
                    <ExternalLink className="size-3.5" /> Live demo
                  </a>
                  <a
                    href={p.github}
                    className="flex-1 glass text-sm py-2 rounded-lg inline-flex items-center justify-center gap-1.5 hover:bg-foreground/5"
                  >
                    <Github className="size-3.5" /> Code
                  </a>
                </div>
              </div>
            </motion.article>
          ))}
        </AnimatePresence>
      </motion.div>
    </Section>
  );
}
