import { motion } from "framer-motion";
import { Section } from "./Section";
import { skills } from "@/data/portfolio";

export function Skills() {
  return (
    <Section id="skills" kicker="Toolkit" title="Skills & Technologies">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {skills.map((cat, ci) => (
          <motion.div
            key={cat.category}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: ci * 0.08 }}
            className="glass rounded-2xl p-6"
          >
            <h3 className="font-semibold text-lg mb-5 flex items-center gap-2">
              <span className="size-2 rounded-full gradient-bg" />
              {cat.category}
            </h3>
            <ul className="space-y-4">
              {cat.items.map((item, i) => (
                <li key={item.name}>
                  <div className="flex items-center justify-between mb-1.5 text-sm">
                    <span className="inline-flex items-center gap-2">
                      <item.Icon className="size-4 text-primary" /> {item.name}
                    </span>
                    <span className="text-muted-foreground text-xs">{item.level}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-foreground/10 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${item.level}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1.1, delay: 0.1 + i * 0.06, ease: "easeOut" }}
                      className="h-full gradient-bg"
                    />
                  </div>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}
