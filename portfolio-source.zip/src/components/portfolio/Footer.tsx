import { Github, Linkedin, Mail, Heart } from "lucide-react";
import { profile } from "@/data/portfolio";

export function Footer() {
  return (
    <footer className="border-t border-border py-10 px-4 mt-10">
      <div className="mx-auto max-w-6xl flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
        <div>
          © {new Date().getFullYear()} {profile.name}. Built with{" "}
          <Heart className="inline size-3.5 text-primary" /> using React & Tailwind.
        </div>
        <div className="flex items-center gap-3">
          <a href={`mailto:${profile.email}`} aria-label="Email" className="hover:text-primary"><Mail className="size-4" /></a>
          <a href={profile.linkedin} aria-label="LinkedIn" className="hover:text-primary"><Linkedin className="size-4" /></a>
          <a href={profile.github} aria-label="GitHub" className="hover:text-primary"><Github className="size-4" /></a>
        </div>
      </div>
    </footer>
  );
}
