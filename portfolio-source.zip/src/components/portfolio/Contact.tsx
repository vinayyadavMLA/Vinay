import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, MapPin, Send, Github, Linkedin, CheckCircle2 } from "lucide-react";
import { Section } from "./Section";
import { profile } from "@/data/portfolio";

export function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    if (!form.name.trim() || form.name.length > 100) return setErr("Please enter your name (max 100 chars).");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) return setErr("Please enter a valid email.");
    if (!form.message.trim() || form.message.length > 1000) return setErr("Message is required (max 1000 chars).");

    // EmailJS or backend integration goes here.
    // For demo, fall back to mailto so the form is functional out of the box.
    const subject = encodeURIComponent(`Portfolio contact from ${form.name}`);
    const body = encodeURIComponent(`${form.message}\n\n— ${form.name} (${form.email})`);
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
    setSent(true);
  };

  return (
    <Section id="contact" kicker="Let's talk" title="Get in touch">
      <div className="grid lg:grid-cols-[1fr_1.2fr] gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="glass rounded-2xl p-6 space-y-5"
        >
          <h3 className="text-xl font-semibold">Reach me directly</h3>
          <a href={`mailto:${profile.email}`} className="flex items-center gap-3 group">
            <div className="size-10 rounded-xl gradient-bg flex items-center justify-center">
              <Mail className="size-4 text-primary-foreground" />
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Email</div>
              <div className="text-sm group-hover:gradient-text transition-colors">{profile.email}</div>
            </div>
          </a>
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-xl gradient-bg flex items-center justify-center">
              <MapPin className="size-4 text-primary-foreground" />
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Location</div>
              <div className="text-sm">{profile.location}</div>
            </div>
          </div>
          <div className="flex gap-2 pt-3">
            <a href={profile.linkedin} aria-label="LinkedIn" className="glass p-3 rounded-xl hover:bg-foreground/5">
              <Linkedin className="size-5" />
            </a>
            <a href={profile.github} aria-label="GitHub" className="glass p-3 rounded-xl hover:bg-foreground/5">
              <Github className="size-5" />
            </a>
          </div>
          <div className="rounded-xl overflow-hidden border border-border h-44">
            <iframe
              title="Location map"
              src="https://www.openstreetmap.org/export/embed.html?bbox=77.45%2C12.83%2C77.75%2C13.05&layer=mapnik"
              className="size-full"
              loading="lazy"
            />
          </div>
        </motion.div>

        <motion.form
          onSubmit={submit}
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="glass rounded-2xl p-6 space-y-4"
        >
          <div>
            <label htmlFor="name" className="text-sm mb-1.5 block">Name</label>
            <input
              id="name"
              maxLength={100}
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full px-4 py-3 rounded-xl bg-foreground/5 border border-border focus:outline-none focus:border-primary transition-colors"
              placeholder="Your name"
            />
          </div>
          <div>
            <label htmlFor="email" className="text-sm mb-1.5 block">Email</label>
            <input
              id="email"
              type="email"
              maxLength={255}
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full px-4 py-3 rounded-xl bg-foreground/5 border border-border focus:outline-none focus:border-primary transition-colors"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label htmlFor="msg" className="text-sm mb-1.5 block">Message</label>
            <textarea
              id="msg"
              rows={5}
              maxLength={1000}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              className="w-full px-4 py-3 rounded-xl bg-foreground/5 border border-border focus:outline-none focus:border-primary transition-colors resize-none"
              placeholder="Tell me about your opportunity..."
            />
          </div>
          {err && <div className="text-sm text-destructive">{err}</div>}
          {sent && (
            <div className="text-sm text-green-400 flex items-center gap-2">
              <CheckCircle2 className="size-4" /> Your mail client should have opened. Thanks for reaching out!
            </div>
          )}
          <button
            type="submit"
            className="w-full gradient-bg text-primary-foreground py-3 rounded-xl font-medium inline-flex items-center justify-center gap-2 hover:scale-[1.02] transition-transform neon-glow"
          >
            <Send className="size-4" /> Send message
          </button>
        </motion.form>
      </div>
    </Section>
  );
}
