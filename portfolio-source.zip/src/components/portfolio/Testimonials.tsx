import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Quote, ChevronLeft, ChevronRight } from "lucide-react";
import { Section } from "./Section";
import { testimonials } from "@/data/portfolio";

export function Testimonials() {
  const [i, setI] = useState(0);
  const next = () => setI((p) => (p + 1) % testimonials.length);
  const prev = () => setI((p) => (p - 1 + testimonials.length) % testimonials.length);

  useEffect(() => {
    const t = setInterval(next, 6000);
    return () => clearInterval(t);
  }, []);

  const cur = testimonials[i];

  return (
    <Section id="testimonials" kicker="Kind words" title="Testimonials">
      <div className="relative max-w-3xl mx-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={i}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.4 }}
            className="glass rounded-3xl p-8 sm:p-12 text-center"
          >
            <Quote className="size-10 gradient-text mx-auto mb-4" />
            <p className="text-lg sm:text-xl leading-relaxed text-foreground/90">
              "{cur.quote}"
            </p>
            <div className="mt-6">
              <div className="font-semibold">{cur.name}</div>
              <div className="text-sm text-muted-foreground">{cur.role}</div>
            </div>
          </motion.div>
        </AnimatePresence>

        <div className="flex items-center justify-between mt-6">
          <button onClick={prev} aria-label="Previous" className="glass p-3 rounded-full hover:bg-foreground/5">
            <ChevronLeft className="size-5" />
          </button>
          <div className="flex gap-2">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setI(idx)}
                aria-label={`Go to testimonial ${idx + 1}`}
                className={`h-2 rounded-full transition-all ${i === idx ? "w-8 gradient-bg" : "w-2 bg-foreground/20"}`}
              />
            ))}
          </div>
          <button onClick={next} aria-label="Next" className="glass p-3 rounded-full hover:bg-foreground/5">
            <ChevronRight className="size-5" />
          </button>
        </div>
      </div>
    </Section>
  );
}
